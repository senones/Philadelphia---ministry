import React from 'react';
import { Helmet } from 'react-helmet';
import Page from '@/components/builder/Page';
import Header from '@/pages/builder/shared/Header';
import Footer from '@/pages/builder/shared/Footer';
import Section1 from './Section1';
import Section2 from './Section2';
import Section3 from './Section3';
import Section4 from './Section4';
import Section5 from './Section5';
import SectionVision from './SectionVision';
import SectionProjekte from './SectionProjekte';

export default function HomePage() {
	return (
		<>
			<Helmet>
				<html lang="de" />
			</Helmet>
			<Page
				pageId={"home"}
				locale={"system"}
				style={{
					"--h1-font-size": "64px",
					"--h1-font-style": "normal",
					"--h1-font-family": "var(--font-primary)",
					"--h1-font-weight": 400,
					"--h1-line-height": "1.2",
					"--h1-m-font-size": "40px",
					"--h1-letter-spacing": 0,
					"--h1-text-transform": "none",
					"--h1-text-decoration": "none",
					"--h2-font-size": "48px",
					"--h2-font-style": "normal",
					"--h2-font-family": "var(--font-primary)",
					"--h2-font-weight": 400,
					"--h2-line-height": "1.25",
					"--h2-m-font-size": "34px",
					"--h2-letter-spacing": 0,
					"--h2-text-transform": "none",
					"--h2-text-decoration": "none",
					"--h3-font-size": "34px",
					"--h3-font-style": "normal",
					"--h3-font-family": "var(--font-primary)",
					"--h3-font-weight": 400,
					"--h3-line-height": "1.3",
					"--h3-m-font-size": "28px",
					"--h3-letter-spacing": 0,
					"--h3-text-transform": "none",
					"--h3-text-decoration": "none",
					"--h4-font-size": "18px",
					"--h4-font-style": "normal",
					"--h4-font-family": "var(--font-primary)",
					"--h4-font-weight": 400,
					"--h4-line-height": "1.4",
					"--h4-m-font-size": "16px",
					"--h4-letter-spacing": 0,
					"--h4-text-transform": "none",
					"--h4-text-decoration": "none",
					"--h5-font-size": "18px",
					"--h5-font-style": "normal",
					"--h5-font-family": "var(--font-primary)",
					"--h5-font-weight": 400,
					"--h5-line-height": "1.4",
					"--h5-m-font-size": "16px",
					"--h5-letter-spacing": 0,
					"--h5-text-transform": "none",
					"--h5-text-decoration": "none",
					"--h6-font-size": "18px",
					"--h6-font-style": "normal",
					"--h6-font-family": "var(--font-primary)",
					"--h6-font-weight": 400,
					"--h6-line-height": "1.4",
					"--h6-m-font-size": "16px",
					"--h6-letter-spacing": 0,
					"--h6-text-transform": "none",
					"--h6-text-decoration": "none",
					"--body-font-size": "16px",
					"--body-font-style": "normal",
					"--body-font-family": "var(--font-secondary)",
					"--body-font-weight": 400,
					"--body-line-height": "1.75",
					"--body-m-font-size": "16px",
					"--body-letter-spacing": 0,
					"--body-text-transform": "none",
					"--body-text-decoration": "none",
					"--font-primary": "'Work Sans', sans-serif",
					"--font-secondary": "'Spectral', serif",
					"--nav-link-font-size": "15px",
					"--nav-link-font-style": "normal",
					"--nav-link-font-family": "var(--font-secondary)",
					"--nav-link-font-weight": 400,
					"--nav-link-line-height": "1.5",
					"--nav-link-m-font-size": "15px",
					"--nav-link-letter-spacing": 0,
					"--nav-link-text-transform": "none",
					"--nav-link-text-decoration": "none",
					"--body-large-font-size": "16px",
					"--body-large-font-style": "normal",
					"--body-large-font-family": "var(--font-secondary)",
					"--body-large-font-weight": 400,
					"--body-large-line-height": "1.75",
					"--body-large-m-font-size": "16px",
					"--body-large-letter-spacing": 0,
					"--body-large-text-transform": "none",
					"--body-large-text-decoration": "none",
					"--body-small-font-size": "13px",
					"--body-small-font-style": "normal",
					"--body-small-font-family": "var(--font-secondary)",
					"--body-small-font-weight": 400,
					"--body-small-line-height": "1.5",
					"--body-small-m-font-size": "13px",
					"--body-small-letter-spacing": 0,
					"--body-small-text-transform": "none",
					"--body-small-text-decoration": "none",
					"--grid-button-primary-font-size": "15px",
					"--grid-button-primary-padding-x": "30px",
					"--grid-button-primary-padding-y": "17px",
					"--grid-button-primary-font-color": "#000000",
					"--grid-button-primary-font-style": "normal",
					"--grid-button-primary-border-null": "",
					"--grid-button-primary-color-hover": "rgb(247, 244, 239)",
					"--grid-button-primary-font-family": "var(--font-secondary)",
					"--grid-button-primary-font-weight": 500,
					"--grid-button-primary-line-height": "1.3",
					"--grid-button-primary-m-font-size": "15px",
					"--grid-button-primary-m-padding-x": "24px",
					"--grid-button-primary-m-padding-y": "15px",
					"--grid-button-primary-box-shadow-x": "0px",
					"--grid-button-primary-box-shadow-y": "4px",
					"--grid-button-primary-border-radius": "999px",
					"--grid-button-primary-letter-spacing": "normal",
					"--grid-button-primary-text-transform": "none",
					"--grid-button-primary-box-shadow-blur": "16px",
					"--grid-button-primary-box-shadow-null": "",
					"--grid-button-primary-text-decoration": "none",
					"--grid-button-primary-background-color": "rgb(217, 155, 67)",
					"--grid-button-primary-box-shadow-color": "rgba(0, 0, 0, 0.12)",
					"--grid-button-primary-border-null-hover": "",
					"--grid-button-primary-box-shadow-spread": "0px",
					"--grid-button-primary-box-shadow-x-hover": "0px",
					"--grid-button-primary-box-shadow-y-hover": "6px",
					"--grid-button-primary-transition-duration": "0.2s",
					"--grid-button-primary-background-color-null": "",
					"--grid-button-primary-box-shadow-blur-hover": "20px",
					"--grid-button-primary-box-shadow-null-hover": "",
					"--grid-button-primary-background-color-hover": "rgb(35, 28, 24)",
					"--grid-button-primary-box-shadow-color-hover": "rgba(0, 0, 0, 0.18)",
					"--grid-button-primary-box-shadow-spread-hover": "0px",
					"--grid-button-primary-transition-timing-function": "ease",
					"--grid-button-primary-background-color-null-hover": "",
					"--grid-button-secondary-font-size": "15px",
					"--grid-button-secondary-padding-x": "30px",
					"--grid-button-secondary-padding-y": "17px",
					"--grid-button-secondary-font-color": "rgb(247, 244, 239)",
					"--grid-button-secondary-font-style": "normal",
					"--grid-button-secondary-border-null": "",
					"--grid-button-secondary-color-hover": "rgb(35, 28, 24)",
					"--grid-button-secondary-font-family": "var(--font-secondary)",
					"--grid-button-secondary-font-weight": 500,
					"--grid-button-secondary-line-height": "1.3",
					"--grid-button-secondary-m-font-size": "15px",
					"--grid-button-secondary-m-padding-x": "24px",
					"--grid-button-secondary-m-padding-y": "15px",
					"--grid-button-secondary-box-shadow-x": "0px",
					"--grid-button-secondary-box-shadow-y": "2px",
					"--grid-button-secondary-border-radius": "999px",
					"--grid-button-secondary-letter-spacing": "normal",
					"--grid-button-secondary-text-transform": "none",
					"--grid-button-secondary-box-shadow-blur": "10px",
					"--grid-button-secondary-box-shadow-null": "",
					"--grid-button-secondary-text-decoration": "none",
					"--grid-button-secondary-background-color": "rgba(0, 0, 0, 0)",
					"--grid-button-secondary-box-shadow-color": "rgba(0, 0, 0, 0.08)",
					"--grid-button-secondary-border-null-hover": "",
					"--grid-button-secondary-box-shadow-spread": "0px",
					"--grid-button-secondary-box-shadow-x-hover": "0px",
					"--grid-button-secondary-box-shadow-y-hover": "4px",
					"--grid-button-secondary-transition-duration": "0.2s",
					"--grid-button-secondary-background-color-null": "",
					"--grid-button-secondary-box-shadow-blur-hover": "14px",
					"--grid-button-secondary-box-shadow-null-hover": "",
					"--grid-button-secondary-background-color-hover": "rgb(247, 244, 239)",
					"--grid-button-secondary-box-shadow-color-hover": "rgba(0, 0, 0, 0.14)",
					"--grid-button-secondary-box-shadow-spread-hover": "0px",
					"--grid-button-secondary-transition-timing-function": "ease",
					"--grid-button-secondary-background-color-null-hover": ""
				}}
				googleFontsHref={null}
				customFontsCss={""}
			>
				<Header />
				<div className="page__blocks">
					<Section1 />
					<Section2 />
					<SectionVision />
					<Section3 />
					<SectionProjekte />
					<Section4 />
					<Section5 />
					<Footer />
				</div>
			</Page>
		</>
	);
}
